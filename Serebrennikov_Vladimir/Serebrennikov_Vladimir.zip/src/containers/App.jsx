import React, {Component} from "react";
import ChatContainer from "./ChatContainer.jsx"

export default class App extends React.Component {
  render() {
      return (
          <ChatContainer></ChatContainer>
      )
  }
}